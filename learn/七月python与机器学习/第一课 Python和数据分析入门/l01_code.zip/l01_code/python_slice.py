li = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

# 切片
print(li[2:5])
print(li[:4])
print(li[5:])
print(li[:])
print(li[0:6:2])
print(li[3::2])
print('')

# 负数索引和step
print(li[::-1])
print(li[::-2])
print(li[-6:-1:1])
print(li[-1::-1])
